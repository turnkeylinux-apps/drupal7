Checkout the Drupal CVS branch in accordance to your version of Drupal...

Drupal 6:
  DRUPAL-6--1

Drupal 5:
  DRUPAL-5

HEAD is meant to be run against Drupal HEAD until the main Drupal branch is
created.
