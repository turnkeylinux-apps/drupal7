Readme
------
Tagadelic is a small module, without any databases, or configuration, that generates pages with weighted tags.
Tagadelic is bothe an out of the box, ready to use module, if you want simple weighted tag clouds. With, or without some small CSS moderations this will probably suit most cases. 
But tagadelic is an API system too. You can pass your queries to the APIs and get weighted clouds of virtually anything: clouds by amout of views, clouds for a certain user, etceteras. The module does not do all this, but you can make it do that, with quite little coding.

More on http://www.webschuur.com/modules/tagadelic

Carpentered in the webschuur.com by Bèr Kessels

